import {PrismaClient,Role} from "@prisma/client";
import bcrypt from "bcryptjs";
const db=new PrismaClient();
async function main(){
 const email=process.env.ADMIN_BOOTSTRAP_EMAIL, password=process.env.ADMIN_BOOTSTRAP_PASSWORD;
 if(!email||!password){console.log("Admin not created: set ADMIN_BOOTSTRAP_EMAIL and ADMIN_BOOTSTRAP_PASSWORD in the secret manager.");return}
 if(password.length<16) throw new Error("ADMIN_BOOTSTRAP_PASSWORD must be at least 16 characters");
 await db.user.upsert({where:{email},update:{},create:{email,name:"Platform admin",role:Role.ADMIN,passwordHash:await bcrypt.hash(password,12)}});
 console.log("Admin bootstrap complete. No demo cafes created: add real Saint Petersburg locations manually through admin API.");
}
main().finally(()=>db.$disconnect());
