# Mobile app
Expo React Native client for iOS/Android. The client uses the backend API; it never stores payment secrets.
Set `EXPO_PUBLIC_API_URL` to the deployed HTTPS API origin. For local device testing, use your computer's LAN IP, not localhost.
Before store submission: add production login/OTP UX, payment deep-link return handling, push notifications, accessibility checks, icons/screenshots, privacy declarations, EAS build credentials and store compliance review.
